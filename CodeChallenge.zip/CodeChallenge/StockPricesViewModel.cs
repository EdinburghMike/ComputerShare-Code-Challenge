﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CodeChallenge
{
    public class StockPricesViewModel : INotifyPropertyChanged

    {
        public ICommand OpenFileCommand { get; set; }
        public ICommand SaveFileCommand { get; set; }

        private string mError;
        public string Error
        {
            get => mError;
            set
            {
                mError = value;
                OnPropertyChanged("Error");
            }
        }

        private string m_FileName;
        public string FileName
        {
            get => m_FileName;
            set
            {
                m_FileName = value;
                OnPropertyChanged("FileName");
            }
        }

        private StockPrice m_buy;
        private StockPrice m_sell;

        public StockPrice Buy
        {
            get => m_buy;
            set {
                m_buy = value;
                OnPropertyChanged("Buy");
            }
        }

        public StockPrice Sell
        {
            get => m_sell;
            set
            {
                m_sell = value;
                OnPropertyChanged("Sell");
            }
        }
        private StockPrice TryBuy;
        private double profit;
    
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (null != PropertyChanged)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public StockPricesViewModel()
        {
            OpenFileCommand = new ManageFileCommand(new Action<object>(ReadStockPrices));
            SaveFileCommand = new ManageFileCommand(new Action<object>(SaveBuyAndSell), false);
        }
        

        public void ReadStockPrices(object obj)
        {
            Error = "";
            if (null == obj)
            {
                Error = "No file found for stock prices";
                return;
            }
                
            if (obj is string)
            {
                FileName = obj as string;
                profit = 0;

                using (var sr = new StreamReader(FileName))
                {
                    string s = sr.ReadToEnd();
                    string[] prices = s.Split(',');

                    if (prices.Length < 30)
                    {
                        Error = "File incomplete : Could only read " + prices.Length + " days from file.";
                        return;
                    }

                    if (prices.Length > 30)
                    {
                        Error = "Too many days specified in file for month : " + prices.Length;
                        return;
                    }

                    Buy = new StockPrice(0, 0);
                    TryBuy = new StockPrice(0, 0);
                    Sell = new StockPrice(30, 0);

                    for (int day = 0; day < prices.Length; day++)
                    {
                        double dbl;
                        if (double.TryParse(prices[day], out dbl))
                        {
                            var sp = new StockPrice(day+1, dbl);

                            CalculateProfit(sp);
                        }
                        else
                        {
                            Error = "Problem parsing file for day : " + day+1;
                            break;
                        }
                    }
                    if (profit <= 0)
                        Error = "No Profitable trades found";
                }
            }
           
        }

        public void SaveBuyAndSell(object obj)
        {
            if (null == obj)
            {
                Error = "No file found for stock prices";
                return;
            }

            if (obj is string)
            {
                string fileName = obj as string;
                using (var sw = new StreamWriter(fileName))
                {
                    sw.Write(Buy.Description);
                    sw.Write(',');
                    sw.Write(Sell.Description);
                }
            }
        }

        private void CalculateProfit(StockPrice sp)
        {
            if (sp.Day <= 1)
            {
                TryBuy = sp;
                Buy = sp;
            }
            else
            {
                double workingProfit = sp.Price - TryBuy.Price;
                if (profit < workingProfit)
                {
                    Sell = sp;
                    Buy = TryBuy;
                    profit = workingProfit;
                }
                else if (TryBuy.Price > sp.Price)
                    TryBuy = sp;
            }

        }

    }
}
