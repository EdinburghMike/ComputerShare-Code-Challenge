﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CodeChallenge
{
    class ManageFileCommand : ICommand
    {
        private Action<object> mAction;
        private bool mIsRead = true;

        public ManageFileCommand(Action<object> mAction, bool isRead = true)
        {
            this.mAction = mAction;
            this.mIsRead = isRead;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (mIsRead)
                ExecuteRead();
            else
                ExecuteSave();
        }

        private void ExecuteRead()
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.DefaultExt = ".txt";
            Nullable<bool> result = dlg.ShowDialog();

            if (true == result)
            {
                mAction(dlg.FileName);
            }
        }

        private void ExecuteSave()
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.DefaultExt = ".txt";
            Nullable<bool> result = dlg.ShowDialog();

            if (true == result)
            {
                mAction(dlg.FileName);
            }
        }
    }
}
